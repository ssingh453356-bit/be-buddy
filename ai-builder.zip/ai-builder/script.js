// Optional: You can add small interactivity here if needed
console.log("AI Builders Landing Page Loaded ✅");
